package detectorPack;

import java.io.IOException;
import java.util.Vector;

import javax.bluetooth.*;


public class RemoteDeviceDiscovery {

    public static final Vector <RemoteDevice> devicesDiscovered = new Vector <RemoteDevice> ();
    
    public static void discoverDevices() throws IOException, InterruptedException {

        final Object inquiryCompletedEvent = new Object();
        devicesDiscovered.clear();
        DiscoveryListener listener = new DiscoveryListener() {

            public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {
                devicesDiscovered.addElement(btDevice);
            }

            public void inquiryCompleted(int discType) {
                System.out.println("Device Inquiry completed!");
                synchronized(inquiryCompletedEvent) {
                    inquiryCompletedEvent.notifyAll();
                }
            }

            public void serviceSearchCompleted(int transID, int respCode) {
                ;
            }

            public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {
                ;
            }
        };
        
        synchronized(inquiryCompletedEvent) {
            boolean started = LocalDevice.getLocalDevice().getDiscoveryAgent().startInquiry(DiscoveryAgent.GIAC, listener);
            if (started) {
                System.out.println("Waiting For Device Inquiry To Complete...");
                try {
                   
                    inquiryCompletedEvent.wait();
                }catch(Exception e) {
                    ;
                }
                System.out.println(devicesDiscovered.size() +  " device(s) Found.");
            }
            else{
                System.out.println("Let it be");
            }
        }
    }
}
