package detectorPack;

// Goesh Updated Copy...Update...
import JMyron.JMyron;
import dataLib.Settings;
import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.sql.ResultSet;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.bluetooth.RemoteDevice;
import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import libpack.BluetoothID;
import libpack.Userdetails;
import sun.net.smtp.SmtpClient;

public class MainForm extends javax.swing.JFrame implements SerialPortEventListener {

    int currentChannel;
    int sensorval[];
    int IRsensorval = 0;
    MainForm parent;
    BluetoothID btid;
    DiscoverTimerTaskk btt;
    Timer bttTimer;
    //for Reciving Status.....
    ReadStatusFromOwnerTask reciveSt;
    Timer reciveTimer;
    //for BT
    Vector<RemoteDevice> discoveredDevices;
    RemoteDevice rd;
    String bluetoothUID = "";
    Settings settings;
    String comPort;
    CommPortIdentifier portId;
    OutputStream outputStream;
    InputStream inputStream;
    SerialPort serialPort;
    boolean flag = true;
    public boolean dataReady;
    public int inData = 0;
    public int IRinData = 0;
    boolean foundBTID = false;
    boolean toCallServer = false;
    Userdetails ci;
    Vector<Userdetails> allClient;
    String ownerEmail = ""; //public boolean unlock = false;
    boolean sendMail = false, isSend = false;
    String CurrentSysTime = "";
    String OpenDoorTime = "15:00:00";
    String CloseDoorTime = "16:00:00";
    boolean openDoorTime = false;

    //Third Timer..............
    class ReadStatusFromOwnerTask extends TimerTask {

        int progress = 0;
        // RemoteDeviceDiscovery remoteDeviceDiscovery;
        MainForm parent;
        boolean deviceStatus = false;
        boolean start = false;
        String status;

        public ReadStatusFromOwnerTask(MainForm parent) {
            //remoteDeviceDiscovery = new RemoteDeviceDiscovery();
            this.parent = parent;
            // getOwnerInfo();
        }

//          for (int i = 0; k < allClient.size(); k++) 
//          {
//            System.out.println("Owner EmailID--------------->" + allClient.elementAt(k).email);
//            ownerEmail = allClient.elementAt(k).email;
//                    }
        public void run() {

            String outputOwnerResponse = reciveStatusFromOwner();
            System.out.println("OUTPUT GOT FROM TEMP TABLE :" + outputOwnerResponse);
            if (outputOwnerResponse.equalsIgnoreCase("unlock")) {
                // parent.unlock=true;
                parent.writeData(35);
                parent.writeData(0x01);
            } else {

                return;
            }
        }
    }

    //Second Timer..............
    class CompareIDS extends TimerTask {

        @Override
        public void run() {

            if (foundBTID == true && toCallServer == true) {

                // reciveStatusFromOwner();
                boolean currentResponse = SendComparIDwithDB();// Send BTID 
                //  IF BT IS EXIST OR NOT IN DB
                if (currentResponse) {     //Here To Chech First Current BTID Compare With Databas BTID..............................
                    writeData(35);
                    writeData(0x01);
                    toCallServer = false;
                } else {
                    toCallServer = false;
                    getOwnerInfo();
                    for (int i = 0; i < allClient.size(); i++) {
                        System.out.println("Owner EmailID--------------->" + allClient.elementAt(i).email);
                        ownerEmail = allClient.elementAt(i).email;
                    }
                    System.out.println("************SENDING MAIL TO OWNER****************");
                    System.out.println("OWNER EMAIL ID-------->" + ownerEmail);
                    sendEmail(ownerEmail, "Alert mail", "Unknown User is Found:");//     Send Mail To Owner.............
                }

            }


        }
    }

    //First Timer..............
    class DiscoverTimerTaskk extends TimerTask {

        int progress = 0;
        RemoteDeviceDiscovery remoteDeviceDiscovery;
        MainForm parent;
        boolean deviceStatus = false;
        boolean start = false;

        public DiscoverTimerTaskk(MainForm parent) {
            remoteDeviceDiscovery = new RemoteDeviceDiscovery();
            this.parent = parent;
        }

        public void run() {


            try {
                // First run RemoteDeviceDiscovery and use discovered device
                remoteDeviceDiscovery.discoverDevices();
                //addStatus("Done Discovering Devices.");
                for (Enumeration en = RemoteDeviceDiscovery.devicesDiscovered.elements(); en.hasMoreElements();) {

                    RemoteDevice btDevice = (RemoteDevice) en.nextElement();
                    if (btDevice.getBluetoothAddress() != null) {
                        start = true;
                        parent.bluetoothUID = "" + btDevice;
                        foundBTID = true;
                        toCallServer = true;



                    } else {
                        foundBTID = false;
                    }
                }

            } catch (Exception e) {
                System.out.println("Exception : " + e);
                System.out.println("can Not Find BT support");
            }

        }
    }

    /////////////////////////////////////  Timer Task For Sensor.....
    class MyTimerTaskForSensor extends TimerTask {

        @Override
        public void run() {

            if (dataReady) {
                dataReady = false;
                sensorval[currentChannel] = inData;
                if (currentChannel == 0) {
                    System.out.println("MOTION IR SENSOR-----*************--->" + sensorval[0]);
                } else if (currentChannel == 1) {
                    System.out.println("VIBRATION SENSOR(Potentiometer)--->" + sensorval[1]);
                }


//                currentChannel++;
//                if (currentChannel == 2) {
//                    currentChannel = 0;
//                }


                // Code For VIBRATION SENSOR..... 
                if (sensorval[1] > 200) {
                    sendMail = true;

                    for (int p = 0; p < allClient.size(); p++) {
                        //System.out.println("Owner EmailID--------------->" + allClient.elementAt(p).email);
                        ownerEmail = allClient.elementAt(p).email;
                    }
                    if (sendMail && !isSend) {
                        isSend = true;
                        System.out.println("##################--VIBRATION VALUE IS GREATER SENDING MAIL TO OWNER--#################");
                        System.out.println("OWNER EMAIL ID-------->" + ownerEmail);
                        sendEmail(ownerEmail, "Alert mail", "Someone is Hammering On the Door");//     Send Mail To Owner.............   
                        sendMail = false;
                    }
                }

                // Code For MOTION IR SENSOR 

                if (sensorval[0] <= 8) {
                    running=true;
                    sensorval[0] = 180;
                   
                    System.out.println("MOTION IR SENSOR-----******IN IF*******--->" + sensorval[0]);
                   // CameraOpen();
                    sendMail = true;
                    for (int p = 0; p < allClient.size(); p++) {
                        //System.out.println("Owner EmailID--------------->" + allClient.elementAt(p).email);
                        ownerEmail = allClient.elementAt(p).email;
                    }

                    if (sendMail && !isSend) {
                        isSend = true;
                        System.out.println("***--------SOMEONE IS INFORNT OF THE DOOR---------***");
                        System.out.println("OWNER EMAIL ID-------->" + ownerEmail);
                        sendEmail(ownerEmail, "Alert mail", "SOMEONE IS INFORNT OF THE DOOR");//     Send Mail To Owner.............   
                        sendMail = false;
                         running=true;
                    }
                    
//                   if (sensorval[0] == 180 ) 
//                   {
//                 running=true;
//                   }
                }




                //End//
                currentChannel++;
                if (currentChannel == 2) {
                    currentChannel = 0;
                }

            }
            writeData(73);
            writeData(currentChannel);
        }
    }
    ///////////////////////////////////////////////////////////////

    /////
//    class MyTimerForRISensor extends TimerTask {
//
//        @Override
//        public void run() {
//
//            if (dataReady) {
//                dataReady = false;
//                IRsensorval = inData;
//                System.out.println("Received value is From IR Sensor Distance---------->" + IRsensorval);
//
////                for (int p = 0; p < allClient.size(); p++) {
////                    //System.out.println("Owner EmailID--------------->" + allClient.elementAt(p).email);
////                    ownerEmail = allClient.elementAt(p).email;
////                }
////                if (sensorval > 200) {
////                    sendMail = true;
////
////                    if (sendMail && !isSend) {
////                        isSend = true;
////                        System.out.println("##################--VIBRATION VALUE IS GREATER SENDING MAIL TO OWNER--#################");
////                        System.out.println("OWNER EMAIL ID-------->" + ownerEmail);
////                        sendEmail(ownerEmail, "Alert mail", "Someone is Hammering On the Door");//     Send Mail To Owner.............   
////                        sendMail = false;
////                    }
////                }
//            }
////            writeData(73);
//            //           writeData(0);
//        }
//    }
    /////   
    
    
    
    // Door Open Foe Some Time.................
    class DooropenforSpecificTime extends TimerTask {

        @Override
        public void run() {
            // throw new UnsupportedOperationException("Not supported yet.");

            try {
                DoorOpenAtTime();
            } catch (Exception e) {
                System.out.println("Exception : " + e);
            }



        }
    }
    public BufferedImage thumbImage2;
    public Graphics2D graphics2D2;
    java.util.Timer t1;
    MyTimerTask3 tt;
    public boolean running;
    public BufferedImage thumbCam, thumbImage;
    public Graphics2D g2DImage;
    public ImageIcon iiImage;
    public JMyron m; //a camera object
    public int cw, ww;
    public int ch, hh;
    public int frameRate; //fps

    public MainForm(String ComPort, MainForm parent) {
        this.parent = parent;

        initComponents();
        Dimension sd = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(sd.width / 2 - this.getWidth() / 2, sd.height / 2 - this.getHeight() / 2);

        settings = new Settings();
        comPort = ComPort;
        sensorval = new int[2];
        try {
            portId = CommPortIdentifier.getPortIdentifier(comPort);
            serialPort = (SerialPort) portId.open("JEfhNose", 2000);
            inputStream = serialPort.getInputStream();
            outputStream = serialPort.getOutputStream();
            Thread.sleep(1000);
            serialPort.addEventListener(this);
            serialPort.notifyOnDataAvailable(true);
            serialPort.setSerialPortParams(9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
        } catch (Exception e) {
            System.out.println("Some Exception: " + e);
            flag = false;
        }

        if (flag) {
            System.out.println("Serial Port Initialized!");
        }
        dataReady = false;

        //for BT
        discoveredDevices = new Vector<RemoteDevice>();////
        rd = null;

        // looking & loading existing settings...
        try {
            ObjectInputStream in1 = new ObjectInputStream(new FileInputStream(System.getProperty("user.dir") + "\\settings.dat"));
            settings = (Settings) in1.readObject();
            in1.close();
        } catch (Exception e) {
            System.out.println("Settings not found. Creating New Default Settings.");
        }
        updateSettings();


        // start sms service
        try {
            new ProcessBuilder("java", "-jar", System.getProperty("user.dir") + "\\autoSms.jar").start();
        } catch (Exception e) {
            System.out.println("Exception Starting SMS Server: " + e);
        }


        getOwnerInfo();

        fillCamera();


    }

    void fillCamera() {
        cw = 320;
        ch = 240;
        ww = 320;
        hh = 240;

        System.out.println("Initializing Webcam, w:" + cw + ", h:" + ch);
        m = new JMyron();//make a new instance of the object
        m.start(cw, ch);//start a capture at 320x240
        m.findGlobs(0);//disable the intelligence to speed up frame rate
        cw = m.getForcedWidth();
        ch = m.getForcedHeight();
        System.out.println("Forced Dimensions, w:" + cw + ", h:" + ch);

        m.stop();

        // Reinitializing with required dimensions
        System.out.println("Re-Initializing Webcam, w:" + cw + ", h:" + ch);
        m = new JMyron();//make a new instance of the object
        m.start(cw, ch);//start a capture at 320x240
        m.findGlobs(0);//disable the intelligence to speed up frame rate
        cw = m.getForcedWidth();
        ch = m.getForcedHeight();
        System.out.println("Forced Dimensions, w:" + cw + ", h:" + ch);


        thumbCam = new BufferedImage(cw, ch, BufferedImage.TYPE_INT_RGB);
        thumbImage = new BufferedImage(ww, hh, BufferedImage.TYPE_INT_RGB);
        g2DImage = thumbImage.createGraphics();
        iiImage = new ImageIcon(thumbImage);
        jLabel3.setIcon(iiImage);

        running = false;
        t1 = new java.util.Timer();
        tt = new MyTimerTask3();
        t1.schedule(tt, 100, 100);
    }

    class MyTimerTask3 extends TimerTask {

        public MyTimerTask3() {
            ;
        }

//        public void run() {
//            if(!running) {
//                return;
//            }
//            updateImage();
//        }
        public void run() {

            if(!running){
                return;
            }
            updateImage();
        }
    }

    public void updateImage() {
        m.update();//update the camera view
        int[] img = m.image(); //get the normal image of the camera
        thumbCam.setRGB(0, 0, cw, ch, img, 0, cw);
        try {
            File f = new File("D:\\TempImage\\p.png");
            if (f.exists()) {
                f.delete();
            }
            ImageIO.write(thumbCam, "png", new File("D:\\TempImage\\p.png"));
        } catch (Exception e) {
        }
        g2DImage.drawImage(thumbCam, 0, 0, ww, hh, null);
        jLabel3.repaint();

    }

    public void writeData(int data) {
        try {
            outputStream.write(data);
            // System.out.println("OUTDATA: " + data);
        } catch (Exception e) {
            System.out.println("Error writing data : " + e);
        }
    }

    public void updateSettings() {
        try {
            ObjectOutputStream out1 = new ObjectOutputStream(new FileOutputStream(System.getProperty("user.dir") + "\\settings.dat"));
            out1.writeObject(settings);
            out1.close();
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }

    public void CameraOpen() {
        //setVisible(false);
        new CameraTest(this).setVisible(true);
    }

    public void DoorOpenAtTime() {

        // For Time..

        CurrentSysTime = new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime());
        // System.out.println("Current System Time----->" + new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime()));

        if (CurrentSysTime.equals("15:00:00")) {
            writeData(35);
            writeData(0x01);
        }

        if (CurrentSysTime.equals("16:00:00")) {
            writeData(35);
            writeData(0x01);
        } else {
            // System.out.println("**********WORKING **********");
        }

    }

    public boolean SendComparIDwithDB() {
        Boolean outputResponse = false;

        // Here To Chech First Current BTID Compare With Databas BTID..............................
        try {
            String urlstr = "http://" + detectorPack.Settings.ipaddress + ":8084/MyServer/ComparIDwithDB";

            URL url = new URL(urlstr);
            URLConnection connection = url.openConnection();
            System.out.println("in server1");

            connection.setDoOutput(true);
            connection.setDoInput(true);

            // don't use a cached version of URL connection
            connection.setUseCaches(false);
            connection.setDefaultUseCaches(false);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            System.out.println("in server2");

            // specify the content type that binary data is sent
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            ObjectOutputStream out = new ObjectOutputStream(connection.getOutputStream());
            // send and serialize the object
            out.writeObject(bluetoothUID);
            out.close();
            System.out.println("in server3");

            // define a new ObjectInputStream on the input stream
            ObjectInputStream in = new ObjectInputStream(connection.getInputStream());
            //receive and deserialize the object, note the cast
            // boolean b = (Boolean) in.readObject();
            outputResponse = (Boolean) in.readObject();
            System.out.println("OUTPUT--------->>  :" + outputResponse);

            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return outputResponse;
    }

    void getOwnerInfo() {


        try {
            String urlstr = "http://" + detectorPack.Settings.ipaddress + ":8084/MyServer/getOwnerData";
            URL url = new URL(urlstr);
            URLConnection connection = url.openConnection();
            System.out.println("in server1");

            connection.setDoOutput(true);
            connection.setDoInput(true);

            // don't use a cached version of URL connection
            connection.setUseCaches(false);
            connection.setDefaultUseCaches(false);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            System.out.println("in server2");

            // specify the content type that binary data is sent
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            ObjectOutputStream out = new ObjectOutputStream(connection.getOutputStream());
            // send and serialize the object
            out.writeObject(ci);
            out.close();
            System.out.println("in server3");

            // define a new ObjectInputStream on the input stream
            ObjectInputStream in = new ObjectInputStream(connection.getInputStream());
            //receive and deserialize the object, note the cast
            allClient = new Vector<Userdetails>();

            allClient = (Vector<Userdetails>) in.readObject();
            System.out.println("SIZE :--------->" + allClient.size());

            System.out.println("in server4");

        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
    }

    String sendEmail(String mailTo, String subject, String contents) {
        String smtpServer = "smtp.net4india.com";
        String mailFrom = "ccfraud@myprojectspace.co.in";
        String ret = "";
        try {
            // from and to
            SmtpClient sc = new SmtpClient(smtpServer);
            sc.from(mailFrom);
            sc.to(mailTo);
            // open a socket connection to server for communication
            PrintStream ps = sc.startMessage();

            // additional headers, subject et al.
            ps.println("From: " + mailFrom);
            ps.println("To: " + mailTo);
            ps.println("Subject: " + subject);
            // blank line separates thel headers and message
            ps.println();
            ps.println(contents);
            sc.closeServer();
        } catch (IOException e) {
            // Should really put up a dialog box informing user of the error
            ret = "Error Sending EMail : " + e;
            System.err.println(e);
            e.printStackTrace();
        }
        System.out.println(ret);
        return ret;
    }

    public String reciveStatusFromOwner() {
        String outputOwnerResponse = "";

        try {
            String urlstr = "http://" + detectorPack.Settings.ipaddress + ":8084/MyServer/reciveStatus";

            URL url = new URL(urlstr);
            URLConnection connection = url.openConnection();
            System.out.println("in server1");

            connection.setDoOutput(true);
            connection.setDoInput(true);

            // don't use a cached version of URL connection
            connection.setUseCaches(false);
            connection.setDefaultUseCaches(false);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            System.out.println("in server2");

            // specify the content type that binary data is sent
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            ObjectOutputStream out = new ObjectOutputStream(connection.getOutputStream());
            // send and serialize the object
            out.writeObject("");
            out.close();
            System.out.println("in server3");

            // define a new ObjectInputStream on the input stream
            ObjectInputStream in = new ObjectInputStream(connection.getInputStream());
            //receive and deserialize the object, note the cast
            // boolean b = (Boolean) in.readObject();
            outputOwnerResponse = (String) in.readObject();
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return outputOwnerResponse;

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jButton8 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jButton5.setFont(new java.awt.Font("Cambria", 0, 18)); // NOI18N
        jButton5.setText("STOP CAMERA");
        jButton5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Cambria", 0, 18)); // NOI18N
        jButton1.setText("ADD BTID");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Cambria", 0, 18)); // NOI18N
        jButton2.setText("MANAGE BTID");
        jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Cambria", 0, 18)); // NOI18N
        jButton4.setText("ADD OWNER INFO");
        jButton4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Cambria", 0, 18)); // NOI18N
        jButton6.setText("MANAGE OWNER INFO");
        jButton6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton9.setFont(new java.awt.Font("Cambria", 0, 18)); // NOI18N
        jButton9.setText("LOG INFO");
        jButton9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Cambria", 0, 18)); // NOI18N
        jButton3.setText("EXIT");
        jButton3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2Layout.createSequentialGroup()
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(jButton2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(jButton1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(jButton5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 206, Short.MAX_VALUE))
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel2Layout.createSequentialGroup()
                                .add(9, 9, 9)
                                .add(jButton4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 216, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(0, 0, Short.MAX_VALUE))
                            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(jButton9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 216, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(jButton6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 216, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))))
                    .add(jButton3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                .add(12, 12, 12)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jButton4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
                    .add(jButton1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jButton2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
                    .add(jButton6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jButton5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
                    .add(jButton9, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jButton3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 45, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 458, -1, -1));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jButton8.setFont(new java.awt.Font("Cambria", 0, 18)); // NOI18N
        jButton8.setForeground(new java.awt.Color(204, 0, 204));
        jButton8.setText("START");
        jButton8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Cambria", 0, 18)); // NOI18N
        jButton7.setForeground(new java.awt.Color(204, 0, 204));
        jButton7.setText("CLOSE DOOR");
        jButton7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jButton8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 303, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jButton7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 260, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(12, 12, 12)
                        .add(jButton8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE))
                    .add(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .add(jButton7, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 366, 597, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImgPkg/dd.jpg"))); // NOI18N
        jLabel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 8, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImgPkg/btt.png"))); // NOI18N
        jLabel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        org.jdesktop.layout.GroupLayout jPanel4Layout = new org.jdesktop.layout.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jLabel4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jLabel4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 232, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(473, 458, -1, 232));

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(619, 458, 333, 232));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImgPkg/se.png"))); // NOI18N
        jLabel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        org.jdesktop.layout.GroupLayout jPanel5Layout = new org.jdesktop.layout.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jLabel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 333, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jLabel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 81, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(619, 366, 333, 81));

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 967, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 706, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

         running=false;
//        setVisible(false);
//        new CameraTest(this).setVisible(true);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

       
        reciveSt.cancel();
        btt.cancel();
        System.exit(0);

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        btt.cancel();
        bttTimer.cancel();
        this.setVisible(false);
        new AddBTIDForm(this).setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.setVisible(false);
        new ManageBTIDForm(this).setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        btt.cancel();
        bttTimer.cancel();

        this.setVisible(false);
        new OwnerInfo(this).setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        this.setVisible(false);
        new ManageOwner().setVisible(true);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed


        writeData(35);
        writeData(0);
        JOptionPane.showConfirmDialog(this, "DOOR CLOSE !!");
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:


        //First Timer  Searching BTID..............
        btt = new DiscoverTimerTaskk(this);
        bttTimer = new Timer();
        bttTimer.schedule(btt, 100, 5000);

        //Second Timer..............
        CompareIDS compareIDS = new CompareIDS();
        Timer cmTimer = new Timer();
        cmTimer.schedule(compareIDS, 100, 5000);

        //Third Timer Recive Status..............
        reciveSt = new ReadStatusFromOwnerTask(this);
        reciveTimer = new Timer();
        reciveTimer.schedule(reciveSt, 100, 5000);



        //Timer For Vibration Sensor

        MyTimerTaskForSensor task;
        Timer t;
        task = new MyTimerTaskForSensor();
        t = new Timer();
        t.schedule(task, 100, 500);



        //Timer For Opening Door Foe Specific Time....

        DooropenforSpecificTime taskk;
        Timer tt;
        taskk = new DooropenforSpecificTime();
        tt = new Timer();
        tt.schedule(taskk, 100, 500);




        //Timer For RI Sensor....  Not Use

//        MyTimerForRISensor task;
//        Timer t;
//        task = new MyTimerForRISensor();
//        t = new Timer();
//        t.schedule(task, 100, 500);







    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
//        btt.cancel();
//        bttTimer.cancel();
        this.setVisible(false);
        new LogInfo(this).setVisible(true);
    }//GEN-LAST:event_jButton9ActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    // End of variables declaration//GEN-END:variables

    public void serialEvent(SerialPortEvent event) {
        switch (event.getEventType()) {
            case SerialPortEvent.DATA_AVAILABLE:
                try {
                    while (inputStream.available() > 0) {
                        inData = inputStream.read();
                        //    System.out.println("IN DATA : " + inData + " dataready flag is:" + dataReady);
                        dataReady = true;
                    }
                } catch (IOException e) {
                    System.out.println("Serial Port Read Error: " + e);
                }
                break;
        }
    }
}
