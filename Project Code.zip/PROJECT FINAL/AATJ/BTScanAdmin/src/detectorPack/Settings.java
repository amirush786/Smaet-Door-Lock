/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package detectorPack;

public class Settings {

    public static String ipaddress;
}
