
package detectorPack;

import JMyron.JMyron;
import java.awt.*;
import java.io.*;
import java.awt.image.*;
import java.awt.*;
import com.sun.image.codec.jpeg.*;
import java.util.TimerTask;
import javax.swing.*;
import JavaLib.*;
import javax.imageio.*;



public class CameraTest extends javax.swing.JFrame {
    MainForm parent;
    public BufferedImage thumbImage2;
    public Graphics2D graphics2D2;
    
    java.util.Timer t1;
    MyTimerTask3 tt;
    public boolean running;
    
    public BufferedImage thumbCam, thumbImage;
    public Graphics2D g2DImage;
    public ImageIcon iiImage;

    public JMyron m; //a camera object
    public int cw, ww;
    public int ch, hh;
    public int frameRate; //fps

    class MyTimerTask3 extends TimerTask{
        public MyTimerTask3() {
            ;
        }

//        public void run() {
//            if(!running) {
//                return;
//            }
//            updateImage();
//        }
        
             public void run() {
         
            updateImage();
        }
    }

    public CameraTest(MainForm parent) {
        this.parent = parent;
        initComponents();
        Dimension sd  = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(sd.width / 2 - this.getWidth()/ 2, sd.height / 2 - this.getHeight()/ 2);
        
       // running = true;    //Start Timer....
        
        cw = 320;
        ch = 240;
        ww = 320;
        hh = 240;
        
        System.out.println("Initializing Webcam, w:" + cw + ", h:" + ch);
        m = new JMyron();//make a new instance of the object
        m.start(cw,ch);//start a capture at 320x240
        m.findGlobs(0);//disable the intelligence to speed up frame rate
        cw = m.getForcedWidth();
        ch = m.getForcedHeight();
        System.out.println("Forced Dimensions, w:" + cw + ", h:" + ch);
        
        m.stop();
        
        // Reinitializing with required dimensions
        System.out.println("Re-Initializing Webcam, w:" + cw + ", h:" + ch);
        m = new JMyron();//make a new instance of the object
        m.start(cw,ch);//start a capture at 320x240
        m.findGlobs(0);//disable the intelligence to speed up frame rate
        cw = m.getForcedWidth();
        ch = m.getForcedHeight();
        System.out.println("Forced Dimensions, w:" + cw + ", h:" + ch);


        thumbCam = new BufferedImage(cw,ch, BufferedImage.TYPE_INT_RGB);
        thumbImage = new BufferedImage(ww,hh, BufferedImage.TYPE_INT_RGB);
        g2DImage = thumbImage.createGraphics();
        iiImage = new ImageIcon(thumbImage);
        jLabelFeed.setIcon(iiImage);
        
        running = false;
        t1 = new java.util.Timer();
        tt = new MyTimerTask3();
        t1.schedule(tt,100,100);
    }
    
    public void updateImage() {
        m.update();//update the camera view
        int[] img = m.image(); //get the normal image of the camera
        thumbCam.setRGB(0,0,cw,ch,img,0,cw);
        try {
             File f = new File("D:\\TempImage\\p.png");
            if (f.exists()) {
                f.delete();
            }
             ImageIO.write(thumbCam, "png", new File("D:\\TempImage\\p.png"));
        } catch (Exception e) {
        }
        g2DImage.drawImage(thumbCam, 0, 0, ww, hh, null);
        jLabelFeed.repaint();

    }
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jBLoadNew = new javax.swing.JButton();
        jBLoadNew1 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabelFeed = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jBLoadNew.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jBLoadNew.setText("START");
        jBLoadNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBLoadNewActionPerformed(evt);
            }
        });

        jBLoadNew1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jBLoadNew1.setText("STOP");
        jBLoadNew1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBLoadNew1ActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jButton1.setText("B A C K");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabelFeed.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelFeed.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgPack/Back320x240.PNG"))); // NOI18N
        jLabelFeed.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        new LoadForm();
        jLabelFeed.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelFeedMouseClicked(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("WEBCAM FEED");
        jLabel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        org.jdesktop.layout.GroupLayout jPanel4Layout = new org.jdesktop.layout.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(jBLoadNew, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 102, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jBLoadNew1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 102, Short.MAX_VALUE)
                        .add(119, 119, 119)
                        .add(jButton1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 102, Short.MAX_VALUE))
                    .add(jLabelFeed, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 431, Short.MAX_VALUE)
                    .add(jLabel4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 431, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel4Layout.linkSize(new java.awt.Component[] {jBLoadNew, jBLoadNew1, jButton1}, org.jdesktop.layout.GroupLayout.HORIZONTAL);

        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel4)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabelFeed, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 266, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jBLoadNew)
                    .add(jBLoadNew1)
                    .add(jButton1))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Cambria", 0, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("LIVE FEED CAMERA ");
        jLabel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jLabel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 455, Short.MAX_VALUE)
                    .add(jPanel4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel1)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabelFeedMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelFeedMouseClicked
// TODO add your handling code here:
        m.settings();
        
    }//GEN-LAST:event_jLabelFeedMouseClicked

    private void jBLoadNew1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBLoadNew1ActionPerformed
// TODO add your handling code here:
        running = false;
    }//GEN-LAST:event_jBLoadNew1ActionPerformed

    private void jBLoadNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBLoadNewActionPerformed
// TODO add your handling code here:
      // running = true;
        
    }//GEN-LAST:event_jBLoadNewActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
// TODO add your handling code here:
        running = false;
        m.stop();
        setVisible(false);
        parent.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBLoadNew;
    private javax.swing.JButton jBLoadNew1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabelFeed;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    // End of variables declaration//GEN-END:variables
    
}
