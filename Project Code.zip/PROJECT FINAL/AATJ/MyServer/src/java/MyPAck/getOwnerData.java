/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPAck;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.sql.*;
import java.util.Vector;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import libpack.Userdetails;

/**
 *
 * @author OorjaTech
 */
@WebServlet(name = "getOwnerData", urlPatterns = {"/getOwnerData"})
public class getOwnerData extends HttpServlet {

    boolean flag;
    Userdetails ci;
    String ssql;
    PreparedStatement pre;
    Connection con;
    Statement stmt;
    Vector<Userdetails> allClient;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {



        try {
            ObjectInputStream in = new ObjectInputStream(request.getInputStream());
            ci = (Userdetails) in.readObject();
            in.close();
            flag = false;
        } catch (Exception e) {
            System.out.println("ERROR IN READING " + e);
        }
        initDatabase();

        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);



            String ssql = "select * from owner";

            System.out.println(ssql);
            ResultSet rs = stmt.executeQuery(ssql);
            //rs.first();
            allClient = new Vector<Userdetails>();
            System.out.println("Query :" + ssql);
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(ssql);
            while (rs.next()) {
                ci = new Userdetails();
                ci.uid = rs.getString(1);
                ci.pass = rs.getString(2);
                ci.fullname = rs.getString(3);
                ci.email = rs.getString(4);
                ci.mob = rs.getString(5);
                ci.address = rs.getString(6);
                allClient.addElement(ci);
                System.out.println("GOT USER");
            }

        } catch (Exception e) {
            System.out.println("ERROR IN WRITING " + e);
        }
        try {
            ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
            out.writeObject(allClient);
            out.close();
        } catch (Exception e) {
            System.out.println("ERROR IN WRITING " + e);
        }

    }

    public void initDatabase() {
        String connection = "jdbc:mysql://localhost/13790DB";
        String user = "root";
        String password = "root";
        String ssql;
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection(connection, user, password);
            System.out.println("Database Connection OK");
        } catch (Exception e) {
            System.out.println("Error opening database : " + e);

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
