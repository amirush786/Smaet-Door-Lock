/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPAck;

import dataLib.Image;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author OorjaTech
 */
@WebServlet(name = "getImages", urlPatterns = {"/getImages"})
public class getImages extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String str = "";
        Image info = new Image();
        try {
            ObjectInputStream in = new ObjectInputStream(request.getInputStream());
            str = (String) in.readObject();
            in.close();
            System.out.println("" + str);

            BufferedImage bi = null;
            File f = new File("D:\\TempImage\\p.png");
            if (f.exists()) {
                bi = ImageIO.read(f);

                ByteArrayOutputStream baos = new ByteArrayOutputStream();

                baos.flush();

                info.img = new int[bi.getWidth() * bi.getHeight()];// baos.toByteArray();
                int cnt = 0, cnt1 = 0;
                for (int y = 0; y < bi.getHeight(); y++) {
                    for (int x = 0; x < bi.getWidth(); x++) {

                        info.img[cnt] = (bi.getRGB(x, y) & 0xffffff);
                        cnt++;
                    }
                }
                info.ww = bi.getWidth();
                info.hh = bi.getHeight();
            } else {
                System.out.println("File not Found");
            }
           // System.out.println("SIZE:" + info.img.length);

            ObjectOutputStream out1 = new ObjectOutputStream(response.getOutputStream());
            out1.writeObject(info);
            out1.close();
        } catch (Exception e) {
            System.out.println("Error:" + e);
            e.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
