/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//package MyPAck;

/*public class Path {
    public static String p="C:\\Users\\bhola\\Desktop\\Avi-Final\\13790-DoorLock-9-Dec-HW\\DoorLock-System\\BTScanAdmin";
}
*/