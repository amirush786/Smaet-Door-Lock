/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPAck;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.sql.*;
import java.util.Vector;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import libpack.BluetoothID;

/**
 *
 * @author OorjaTech
 */
@WebServlet(name = "reciveStatus", urlPatterns = {"/reciveStatus"})
public class reciveStatus extends HttpServlet {

    boolean flag;
    BluetoothID pi;
    String ssql;
    PreparedStatement pre;
    Connection con;
    Statement stmt;
    //String StatusReq = "LOCK";
    String StatusReq = "";  //                     Chachange Here ..........................
    String gotidfrmadmin = "Unknown_Visitor";

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        boolean found = false;
        System.out.println("Reading From Temp Table");
        try {
            ObjectInputStream in = new ObjectInputStream(request.getInputStream());
            in.readObject();
            in.close();
            flag = false;
        } catch (Exception e) {
            System.out.println("ERROR IN READING " + e);
        }



        try {

            initDatabase();
            String ssql = "select * from temp ";
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery(ssql);
            if (rs.next()) {
                StatusReq = "" + rs.getString(1);
                found = true;
            }
        } catch (Exception e) {
            System.out.println("ERROR IN WRITING " + e);
        }

        System.out.println("RECIVE-STATUS OF FOUND ON SERVER---->: " + found);
        try {
            if (found == true) {
                initDatabase();
                //String ssql = "delete from temp";
                String ssql = "TRUNCATE TABLE temp";
                stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                stmt.executeUpdate(ssql);
                System.out.println("DELETED ALL RECORDS FROM TABLE " + found);
            } else {
                StatusReq = "stop";
            }
            ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
            out.writeObject(StatusReq);
            System.out.println("Request Response from owner When Click On Server #########----->" + StatusReq);
            out.close();

        } catch (Exception e) {
            System.out.println("ERROR IN WRITING " + e);
        }



        // For Maintain Log Entries...
        if (found == true) {
            try {
                System.out.println("FOUND REPLY----------->>>>>>>>>>>>>>>>>>>>" + found);
                stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                String ssql = "insert into Logtable values(0,'"+gotidfrmadmin+"',sysDate())";
                System.out.println(ssql);
                stmt.executeUpdate(ssql);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        //End..


    }

    private void initDatabase() {
        String connection = "jdbc:mysql://localhost/13790DB";
        String user = "root";
        String password = "root";
        String ssql;
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection(connection, user, password);
            System.out.println("Database Connection OK");
        } catch (Exception e) {
            System.out.println("Error opening database : " + e);

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
