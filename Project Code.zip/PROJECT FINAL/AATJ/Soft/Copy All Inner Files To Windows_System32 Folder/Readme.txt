java\jdk\lib
java\jre\lib
java\jdk\jre\lib



