package com.example.aboundentobject;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class Welcome extends Activity {

	EditText edtipdata;
	//Button next;
	ImageView imgview;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_welcome);
		edtipdata=(EditText)findViewById(R.id.editIP);
		//next=(Button)findViewById(R.id.btnNext);
		imgview=(ImageView)findViewById(R.id.imageView1);
		
//		next.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				Settings.ip=edtipdata.getText().toString();
//				Intent i=new Intent(getApplicationContext(),LoginForm.class);
//				startActivity(i);
//			}
//		});
		
		
		
		imgview.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Settings.ip=edtipdata.getText().toString();
				Intent i=new Intent(getApplicationContext(),LoginForm.class);
				startActivity(i);
				
			}
		});
		
		
		
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		
		getMenuInflater().inflate(R.menu.welcome, menu);
		return true;
	}

}
