package com.example.aboundentobject;





import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.net.URLConnection;

import libpack.Userdetails;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginForm extends Activity {
	
	
	EditText userName,passwd;
	
	Button loginBtn,regBtn;
	//TextView regUser;
	  boolean flag;
	Userdetails userdata;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login_form);

		
		//regUser=(TextView)findViewById(R.id.textID);
		loginBtn=(Button)findViewById(R.id.loginID);
		userName=(EditText)findViewById(R.id.editText1);
		passwd=(EditText)findViewById(R.id.editText2);
		regBtn=(Button)findViewById(R.id.button1);
		
		
		
		regBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i = new Intent(getApplicationContext(),RegistrationForm.class);
				startActivity(i);
				
			}
		});
		
		loginBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				LoginTest log = new  LoginTest();
				log.execute("");
			
				
			}
		});
	
//		regUser.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View v) {
//				Intent i = new Intent(getApplicationContext(),RegistrationForm.class);
//				startActivity(i);
//				
//			}
//		});
		
		

		



}
	
	private class LoginTest extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			System.out.println("SERVLET CALLED");
			userdata = new Userdetails();
			userdata.uid= userName.getText().toString();
			userdata.pass = passwd.getText().toString();
			
			try {
			//	String urlstr = "http://192.168.1.37:8084/MyServer//LoginServ";
				String urlstr = "http://"+Settings.ip+":8084/MyServer//LoginServer";
				URL url = new URL(urlstr);
				URLConnection connection = url.openConnection();
				System.out.println("in server1");

				connection.setDoOutput(true);
				connection.setDoInput(true);

				// don't use a cached version of URL connection
				connection.setUseCaches(false);
				connection.setDefaultUseCaches(false);
				connection.setRequestProperty("Content-Type",
						"application/x-www-form-urlencoded");
				System.out.println("in server2");

				// specify the content type that binary data is sent
				connection.setRequestProperty("Content-Type",
						"application/x-www-form-urlencoded");
				ObjectOutputStream out = new ObjectOutputStream(
						connection.getOutputStream());
				// send and serialize the object
				out.writeObject(userdata);
				out.close();
				System.out.println("in server3");

				// define a new ObjectInputStream on the input stream
				ObjectInputStream in = new ObjectInputStream(
						connection.getInputStream());
				// receive and deserialize the object, note the cast
				userdata = new Userdetails();
				
				userdata=(Userdetails) in.readObject();
			
				in.close();
			} catch (Exception e) {
				System.out.println("Error:" + e);
			}
			return "";
		}
		
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			if (!userdata.fullname.equals("")) {
				Toast.makeText(getApplicationContext(), "Login Successfully !!",Toast.LENGTH_SHORT).show();
				Intent i = new Intent(getApplicationContext(),MainForm.class);
				startActivity(i);
				
			}
			else {
				Toast.makeText(getApplicationContext(), "Login Failed !!",Toast.LENGTH_SHORT).show();
			}
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
}
