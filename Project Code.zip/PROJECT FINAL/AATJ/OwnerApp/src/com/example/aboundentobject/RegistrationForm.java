package com.example.aboundentobject;



import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import libpack.Userdetails;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistrationForm extends Activity {
	
	
	Button submitBtn;
	EditText userIdText,passwdText,fullNameText,emailText,mobText,addressText;
	Userdetails usdata;
	boolean b=false;
	
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_registration_form);
		submitBtn=(Button)findViewById(R.id.subID);
		userIdText=(EditText)findViewById(R.id.editText1);
		passwdText=(EditText)findViewById(R.id.editText2);
		fullNameText=(EditText)findViewById(R.id.editText3);
		emailText=(EditText)findViewById(R.id.editText4);
		mobText=(EditText)findViewById(R.id.editText5);
		addressText=(EditText)findViewById(R.id.editText6);
		
		
		
		submitBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
	

				if(!validateString(fullNameText.getText().toString()))
				{
					Toast.makeText(getApplicationContext(), "Enter Valid Name !!", Toast.LENGTH_SHORT).show();
					return;
				}
				
				if(!validateEmail( emailText.getText().toString()))
				{
					Toast.makeText(getApplicationContext(), "Enter Valid Email", Toast.LENGTH_SHORT).show();
					return;
				}
				
				if(!validateNumeric(mobText.getText().toString()))
				{
					Toast.makeText(getApplicationContext(), "Enter Valid Mobile No !!", Toast.LENGTH_SHORT).show();
					return;
				}
				
			
				
				
				if(!validateString(addressText.getText().toString()))
				{
					Toast.makeText(getApplicationContext(), "Enter Valid Address !!", Toast.LENGTH_SHORT).show();
					return;
				}
				
			    if (userIdText.getText().equals("") || passwdText.getText().equals("") || fullNameText.getText().equals("") || emailText.getText().equals("") || mobText.getText().equals("") || addressText.getText().equals("")) 
			    {
			    	Toast.makeText(getApplicationContext(), "Enter All Fileds !!", Toast.LENGTH_SHORT).show();
		            return;
		        }	
				
				
				usdata = new Userdetails();
				usdata.uid= userIdText.getText().toString();
				usdata.pass= passwdText.getText().toString();
				usdata.fullname= fullNameText.getText().toString();
				usdata.email= emailText.getText().toString();
				usdata.mob= mobText.getText().toString();
				usdata.address= addressText.getText().toString();
				
				submitInfo sub = new  submitInfo();
				sub.execute("");
				
				
			}
		});
	
	}
	
	private class submitInfo extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			System.out.println("SERVLET CALLED");
			
		
		
			try {
			//	String urlstr = "http://192.168.1.37:8084/MobileVotingServer//LoginServ";
				String urlstr = "http://"+Settings.ip+":8084/MyServer//RegOwnerServ";
				URL url = new URL(urlstr);
				URLConnection connection = url.openConnection();
				System.out.println("in server1");

				connection.setDoOutput(true);
				connection.setDoInput(true);

				// don't use a cached version of URL connection
				connection.setUseCaches(false);
				connection.setDefaultUseCaches(false);
				connection.setRequestProperty("Content-Type",
						"application/x-www-form-urlencoded");
				System.out.println("in server2");

				// specify the content type that binary data is sent
				connection.setRequestProperty("Content-Type",
						"application/x-www-form-urlencoded");
				ObjectOutputStream out = new ObjectOutputStream(
						connection.getOutputStream());
				// send and serialize the object
				out.writeObject(usdata);
				out.close();
				System.out.println("in server3");

				// define a new ObjectInputStream on the input stream
				ObjectInputStream in = new ObjectInputStream(
						connection.getInputStream());
				// receive and deserialize the object, note the cast
				//usdata = new Userdetails();
				//ci= (ClientInfo) in.readObject();
				
				//usdata=(Userdetails) in.readObject();
			    b = (Boolean) in.readObject();
			    in.close();
	           // System.out.println("@@@@@@@@@@@@@@@@RETURN :---->" + b);
	          
	            System.out.println("in server4");
	            //in.readObject();
	           
			} catch (Exception e) {
				System.out.println("Error:" + e);
			}
			return "";
		}
		
		
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			  if (b) {
	               Toast.makeText(getApplicationContext(), "Record Added Successfully !!", Toast.LENGTH_SHORT).show();
	            } else {
	            	Toast.makeText(getApplicationContext(), "Error in Adding !!", Toast.LENGTH_SHORT).show();
	            }
			
		}
		
	
		
	}
	
	
	boolean validateEmail(String email) {
        //Set the email pattern string
        Pattern p = Pattern.compile(".+@.+\\.[a-z]+");
        //Match the given string with the pattern
        Matcher m = p.matcher(email);
        //check whether match is found
        boolean matchFound = m.matches();
        if (matchFound) {
            System.out.println("Valid Email Id.");
            return true;
        } else {
            System.out.println("Invalid Email Id.");
            return false;
        }
    }

    boolean validateNumeric(String num) {
        //Set the email pattern string
        Pattern p = Pattern.compile("[0-9]+");
        //Match the given string with the pattern
        Matcher m = p.matcher(num);
        //check whether match is found
        boolean matchFound = m.matches();
        if (matchFound) {
            return true;
        } else {
            return false;
        }
    }

    boolean validateString(String str) {
        //Set the email pattern string
        Pattern p = Pattern.compile("[a-zA-Z ]+");
        //Match the given string with the pattern
        Matcher m = p.matcher(str);
        //check whether match is found
        boolean matchFound = m.matches();
        if (matchFound) {
            return true;
        } else {
            return false;
        }
    }
	
	
	



}
