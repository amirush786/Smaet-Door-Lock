package com.example.aboundentobject;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.net.URLConnection;

import libpack.Userdetails;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainForm extends Activity {

	Button livefeedBtn, exitBtn, grantBtn;
	boolean flag = false;

	String permission = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_form);

		livefeedBtn = (Button) findViewById(R.id.feedID);
		exitBtn = (Button) findViewById(R.id.exitID);
		grantBtn = (Button) findViewById(R.id.grantID);

		grantBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				permission = "unlock";
				ForOpenDoor log = new ForOpenDoor();
				log.execute("");
				// writeToFile();

			}
		});

		exitBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});

		livefeedBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent i = new Intent(getApplicationContext(), VideoFeed.class);
				startActivity(i);

			}
		});

	}

	
	private class ForOpenDoor extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			System.out.println("SERVLET CALLED");

			try {
				// String urlstr =
				// "http://192.168.1.37:8084/MyServer//LoginServ";
				String urlstr = "http://" + Settings.ip
						+ ":8084/MyServer//AddStatusMsg";
				URL url = new URL(urlstr);
				URLConnection connection = url.openConnection();
				System.out.println("in server1");

				connection.setDoOutput(true);
				connection.setDoInput(true);

				// don't use a cached version of URL connection
				connection.setUseCaches(false);
				connection.setDefaultUseCaches(false);
				connection.setRequestProperty("Content-Type",
						"application/x-www-form-urlencoded");
				System.out.println("in server2");

				// specify the content type that binary data is sent
				connection.setRequestProperty("Content-Type",
						"application/x-www-form-urlencoded");
				ObjectOutputStream out = new ObjectOutputStream(
						connection.getOutputStream());
				// send and serialize the object
				out.writeObject(permission);
				out.close();
				System.out.println("in server3");

				// define a new ObjectInputStream on the input stream
				ObjectInputStream in = new ObjectInputStream(
						connection.getInputStream());
				// receive and deserialize the object, note the cast
				// bo = new Userdetails();

				// userdata=(Userdetails) in.readObject();
				flag = (Boolean) in.readObject();

				in.close();
			} catch (Exception e) {
				System.out.println("Error:" + e);
			}
			return "";
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			if (flag) {
				Toast.makeText(getApplicationContext(), "Opening Door !!",
						Toast.LENGTH_SHORT).show();

			} else {
				Toast.makeText(getApplicationContext(), "Error In Opening !!",
						Toast.LENGTH_SHORT).show();
			}
		}

	}

}
