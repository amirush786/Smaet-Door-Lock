package com.example.aboundentobject;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.net.URLConnection;

import dataLib.Image;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.app.Activity;
import android.graphics.Bitmap;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class VideoFeed extends Activity {

	boolean response = false, posTresp = false;
	Image resImages;
	ImageView img;
	Button btnStart;
	Handler h;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_video_feed);
		btnStart = (Button) findViewById(R.id.button1);
		img = (ImageView) findViewById(R.id.imageView1);

		h = new Handler(Looper.getMainLooper());
		h.post(new Runnable() {

			@Override
			public void run() {

				if (posTresp) {
					posTresp = false;

										
					Bitmap myBmp = Bitmap
							.createBitmap(resImages.img, resImages.ww,
									resImages.hh, Bitmap.Config.RGB_565);

					img.setImageBitmap(myBmp);

					
					LongOperation li = new LongOperation();
					li.execute("");
				}

				h.postAtTime(this, SystemClock.uptimeMillis());
			}
		});
		btnStart.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				LongOperation li = new LongOperation();
				li.execute("");
			}
		});
	}

	
	
	
	
	public class LongOperation extends AsyncTask<String, Void, String> {

		@Override
		protected void onPreExecute() {
			response = false;
			super.onPreExecute();
		}

		@Override
		protected String doInBackground(String... params) {
			try {

				String urlstr = "http://" + Settings.ip
						+ ":8084/MyServer/getImages";
				URL url = new URL(urlstr);
				URLConnection connection = url.openConnection();
				// System.out.println("in server1");

				connection.setDoOutput(true);
				connection.setDoInput(true);

				// don't use a cached version of URL connection
				connection.setUseCaches(false);
				connection.setDefaultUseCaches(false);
				connection.setRequestProperty("Content-Type",
						"application/x-www-form-urlencoded");
				// System.out.println("in server2");

				// specify the content type that binary data is sent
				connection.setRequestProperty("Content-Type",
						"application/x-www-form-urlencoded");
				ObjectOutputStream out = new ObjectOutputStream(
						connection.getOutputStream());
				// send and serialize the object
				out.writeObject("");
				out.close();
				// System.out.println("in server3");

				// define a new ObjectInputStream on the input stream
				ObjectInputStream in = new ObjectInputStream(
						connection.getInputStream());
				// receive and deserialize the object, note the cast

				resImages = (Image) in.readObject();

				in.close();
				// System.out.println("Length" + resImages);
			} catch (Exception e) {
				System.out.println("Error:" + e);
				e.printStackTrace();
			}

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			if (resImages == null) {
				Toast.makeText(getApplicationContext(), "Failed..!!!!!!!!!!",
						Toast.LENGTH_SHORT).show();
			} else {
				posTresp = true;
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.video_feed, menu);
		return true;
	}

}
