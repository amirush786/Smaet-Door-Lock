package com.example.aboundentobject;

public class Settings {
	public static String ip = "";
}
